# Changelog

**English** | [한국어](docs/CHANGELOG.ko.md)

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project aims to follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-06-25

### Changed
- Patch sites are now derived dynamically instead of hardcoded. The new
  `patcher::analyze` module disassembles each target function and captures
  struct displacements, register choices, and branch direction at runtime,
  then emits patch bytes through a new hand-rolled `patcher::encode` x86/x64
  instruction encoder (`mov reg, imm32`, `mov [base+disp32], reg`). This
  removes build-dependent hardcoding (fixed struct offsets, register
  enumerations, fixed byte templates) so DefPolicy and PropertyDevice
  patches survive termsrv.dll struct-layout shifts across Windows builds.
  Addresses the issue-#3 class (patches silently not applied after a
  Windows build update); validated on 26200.8037, 26100.32230 (Server
  2025), and 20348.587 (Server 2022).
- Patch-site discovery now follows PGO hot/cold function splits. When a
  target function's identifying string is referenced only from a cold
  (outlined) fragment, the resolver follows the x64 chained unwind info
  (`UNW_FLAG_CHAININFO`) to the primary (hot) function before locating the
  patch site. Without this, DefPolicy resolved to a deny-path fragment and
  was silently skipped on cold-split builds such as Server 2022 (20348).
- `termwrap-dll` DefPolicy and PropertyDevice patch modules are now thin
  unsafe wrappers over the pure `patcher::analyze` analyzers.

### Added
- `offset-finder --dry-run` (`-d`): for each patch, reports the captured
  patch site and the exact bytes that would be written (or NOT FOUND),
  as a self-diagnosis aid. `--assert-all` implies `--dry-run` and now
  also fails when a patch site cannot be located.

### Removed
- `umwrap-dll` x64 legacy slc.dll path no longer writes a build-dependent
  `or [rsp+0x40], 1` stack-slot template. The fragile hardcoded write was
  replaced with a log-and-skip so it cannot corrupt an unrelated stack slot
  on a mismatched build.

## [0.2.0] - 2026-05-13

### Added
- ARM64 Windows build scaffold: `aarch64-pc-windows-msvc` now type-checks
  across the workspace, has static-CRT rustflags, and is covered by a
  CI build/static-artifact job. The release workflow now packages ARM64 ZIPs
  alongside x64 and x86.
- Experimental ARM64 runtime patching for `umwrap-dll` and `endpwrap-dll`.
  `patcher::arm64` now scans ARM64 `.pdata` function entries, resolves
  ADR/ADRP+ADD policy-string references, and locates nearby BL calls.
  `umwrap` replaces the policy BL call with `mov w0,#1`; `endpwrap` replaces
  the referenced audio-capture function start with `mov w0,#1; ret`.
- Experimental ARM64 runtime patching for `termwrap-dll`. The ARM64 path
  resolves the same termsrv policy strings via `.pdata`, patches DefPolicy
  field checks, forces single-session/local-only checks false, forces
  AppServer/NonRDP checks true, patches the PropertyDevice BL result false,
  and patches SL policy query BL calls to return true. Real Windows ARM64 runtime
  validation is still required before treating this as production-supported.

### Fixed
- `rdprrap-installer install --force` now actually replaces existing
  installed wrapper DLLs before the race-safe `CREATE_NEW` copy. Without
  `--force`, an existing destination DLL now fails early with a clear
  "use --force" message instead of surfacing a lower-level Win32 create error.
- `offset-finder` no longer treats ARM64 PE32+ images as x64. Pure ARM64
  `termsrv.dll` images now get an ARM64 string/function/BL-site report;
  ARM64EC/ARM64X hybrid images still report unsupported until separately
  validated.

## [0.1.3] - 2026-04-23

### Fixed (license compliance — continued)
- `NOTICE` was incomplete. 0.1.2 listed 9 rdpwrap-derived files but a
  deeper audit found **16** Rust sources that port from, mirror, or
  reference specific Delphi files in `stascorp/rdpwrap`. `NOTICE` now
  enumerates all of them, grouped by upstream binary
  (`RDPWInst.exe → rdprrap-installer`,
   `RDPConf.exe  → rdprrap-conf`,
   `RDPCheck.exe → rdprrap-check`), so a future reviewer can see the
  derivation boundary per upstream tool rather than per file.
- `CODE_OF_CONDUCT.md` and `docs/CODE_OF_CONDUCT.ko.md` now cite the
  Creative Commons Attribution 4.0 International (CC BY 4.0) license
  that governs the Contributor Covenant text. The prior attribution
  block matched the adopter template on
  <https://www.contributor-covenant.org> but did not name the CC BY
  license itself.
- Copyright-line consistency: `rdprrap-conf`'s About-dialog MIT text
  read "Copyright (c) 2026 rdprrap contributors" while `LICENSE` and
  the bundled `THIRD_PARTY_LICENSES.txt` read "Copyright (c) 2026 Kim
  DaeHyun". Aligned the About dialog to the `LICENSE` text so the
  three places all agree.

## [0.1.2] - 2026-04-23

### Fixed
- Ship upstream source-attribution notices alongside the binaries.
  Portions of rdprrap are reimplementations of, or mirror the behavior
  of, three upstream projects whose licenses require copyright-notice
  preservation and/or license-text distribution:
    * `stascorp/rdpwrap` (Apache-2.0) — RDPCheck disc-reason table,
      installer/cohort-restart/ACL contracts, HKLM registry layout,
      firewall-rule shape. Apache-2.0 §4(a) requires the license text
      to accompany redistribution; §4(c) requires retaining
      attribution notices.
    * `llccd/TermWrap` (MIT) — patcher pattern scanner, PE adjustment,
      x64 xref / x86 prologue-scan function resolution, DLL export
      contract. MIT requires the copyright notice be included in
      every redistribution.
    * `llccd/RDPWrapOffsetFinder` (MIT) — offset-finder algorithmic
      design (string scan, xref, branch-follow priority queue).

  The 0.1.0 / 0.1.1 releases bundled only the Cargo-dependency
  attributions (`THIRD_PARTY_LICENSES.txt`) and were missing these
  three source-level notices. This was a license-compliance gap.

### Added
- **`NOTICE`** file at repo root — names each upstream project, the
  files in rdprrap that derive from it, the license, and the full
  copyright text (inlined MIT notices; Apache-2.0 license reference).
- **`vendor/licenses/`** — verbatim upstream license texts, vendored
  so the release pipeline does not depend on upstream reachability
  at tag time:
    * `LICENSE.rdpwrap.Apache-2.0`
    * `LICENSE.TermWrap.MIT`
    * `LICENSE.RDPWrapOffsetFinder.MIT`
- Release workflow bundles both `NOTICE` and the entire
  `vendor/licenses/` tree into each per-arch release ZIP.
- `README.md` and `docs/README.ko.md` "License" sections now point
  readers at `NOTICE` and `vendor/licenses/` for upstream
  attribution, and at `THIRD_PARTY_LICENSES.txt` for Cargo-dep
  attribution.

## [0.1.1] - 2026-04-22

### Fixed
- `rdprrap-installer` registry readback could leak a stray byte pair
  from the over-allocated buffer tail into the decoded string — the
  pre-install `ServiceDll` value got persisted to
  `HKLM\SOFTWARE\rdprrap\Installer\OriginalServiceDll` with an extra
  trailing character (reported in #1 as `termsrv.dll` → `termsrv.dlll`).
  The rollback path on `uninstall` would then restore that corrupted
  value and leave `TermService` pointing at a non-existent DLL,
  breaking RDP on the next boot.

  Both `RegKey::get_string` and `get_service_dll` now trim the decoded
  buffer to the exact byte count that `RegQueryValueExW` /
  `RegGetValueW` wrote (the `lpcbData` out-param) instead of relying
  on `while buf.last() == Some(0) { pop }` on the full allocation.

### Tests
- Added Windows-only registry round-trip regression tests under
  `HKCU\Software\rdprrap-installer-tests\` — no elevation required, so
  they run on the unprivileged Windows CI runner. Each test creates a
  per-invocation isolated subkey (PID + atomic counter) with an RAII
  cleanup guard that deletes the subtree on drop.

### Mitigation for 0.1.0 installs
Before running `rdprrap-installer.exe uninstall` on a host installed
with 0.1.0, operators should verify the saved `ServiceDll` target:

```
reg query "HKLM\SOFTWARE\rdprrap\Installer" /v OriginalServiceDll
```

If the displayed path does not end in exactly `.dll`, overwrite it
before uninstall:

```
reg add "HKLM\SOFTWARE\rdprrap\Installer" /v OriginalServiceDll ^
  /t REG_EXPAND_SZ /d "%SystemRoot%\System32\termsrv.dll" /f
```

## [0.1.0] - 2026-04-22

### Scope of this release
0.1.0 ships the core multi-session RDP patching pipeline
(`termwrap` + installer + check + conf + offset-finder). The
`umwrap` / `endpwrap` wrappers are included in the install payload
for continuity with the original rdpwrap layout, but are dormant —
see *Known limitations* below. Expansion of supported Windows SKUs
and activation of the USB / camera / audio wrappers are tracked
toward a later release.

### Fixed
- `rdprrap-installer` uninstall path now uses
  `restart_termservice_with_cohort` (same primitive install uses). A
  plain stop/start hit `ERROR_DEPENDENT_SERVICES_RUNNING` (0x041B) on
  any host where `UmRdpService` or `SessionEnv` was active, leaving the
  installer state key + install directory behind because the `?` on
  `start_termservice` bailed out early. Restart failure is now
  non-fatal — cleanup (state-key removal + install-dir cleanup) always
  runs, and the reboot message tells the operator how to finish.
- `.cargo/config.toml` forces `target-feature=+crt-static` for both
  MSVC targets. Without this, binaries depend on
  `VCRUNTIME140.dll` / `MSVCP140.dll` and refuse to start on fresh
  Windows images (STATUS_DLL_NOT_FOUND = 0xC0000135) that do not ship
  the VC++ Redistributable. Verified via `llvm-readobj`: no MSVC CRT
  imports remain on any x64 or i686 artifact.
- Docs: canonical installed name of the audio endpoint wrapper is
  `endpwrap.dll`, not `rdpendp.dll`. The installer contract has always
  said `endpwrap.dll`; the TESTING docs were wrong.

### Verified (runtime, 2026-04-22)
- End-to-end install / uninstall round-trip on Windows 11 x64
  (build 10.0.26200.0) inside a winpodx / dockur-windows container on
  a Linux host.
- Multi-session RDP smoke: two concurrent interactive sessions remain
  usable in parallel, `TermWrap:` patch-applied lines present in
  DebugView, zero `patch not found` entries.
- `offset-finder --assert-all C:\Windows\System32\termsrv.dll`
  resolves 7/7 named strings and 7/7 named functions on that build.
- Uninstall restores `ServiceDll` to `%SystemRoot%\System32\termsrv.dll`,
  deletes the `%ProgramFiles%\RDP Wrapper\` tree, removes the
  `rdprrap-RDP-TCP` / `rdprrap-RDP-UDP` firewall rules, clears
  `HKLM\SOFTWARE\rdprrap\Installer`, and restores the pre-install
  `fDenyTSConnections` value.

### Known limitations
- **Supported SKU is narrow** — only Windows 11 x64 (build
  10.0.26200.0) has been runtime-verified end-to-end. Windows Server
  2025 / 2022, Windows 11 24H2 / 23H2, Windows 10 22H2, and every
  i686 runtime path remain compile + unit-test only. `offset-finder`
  is pattern-based and is expected to degrade gracefully on untested
  `termsrv.dll` builds — if a pattern misses, capture the full
  `--assert-all` stdout plus the `termsrv.dll` VersionInfo so the
  drift can be diagnosed.
- **`umwrap` and `endpwrap` are dormant in this release** — the DLLs
  land in `%ProgramFiles%\RDP Wrapper\` but Windows does not load
  them. `UmRdpService` and the audio-endpoint COM server pull
  `System32\umrdp.dll` and `System32\rdpendp.dll` directly, and
  0.1.0 does not ship a redirection mechanism that survives WFP /
  SFC. The USB / camera / audio-capture patches therefore have no
  runtime effect in 0.1.0 — the multi-session patches in `termwrap`
  are the only runtime-active component. Activation is tracked for a
  future release.
- ACL hardening on `%ProgramFiles%\RDP Wrapper\` relies on Program
  Files parent inheritance rather than an explicit protected DACL.
  Write access is still restricted to SYSTEM / Administrators /
  TrustedInstaller; `BUILTIN\Users` inherits read+execute.
- `Start-Transcript` in Windows PowerShell 5.1 does not capture the
  installer's native console output. Use
  `.\rdprrap-installer.exe install 2>&1 | Tee-Object install.log` for
  reliable capture.

### Added (2026-04)
- **`rdprrap-installer`**: Rust CLI installer/uninstaller — service registration, registry (KEY_WOW64_64KEY + SDDL-protected uninstall key), firewall rules (TCP+UDP 3389, locale-safe names), install-dir ACL hardening (SetEntriesInAclW + SetNamedSecurityInfoW for SYSTEM + LocalService), `netsvcs` cohort service restart, `VerQueryValueW`-based termsrv.dll version check, `--force` / `--skip-firewall` / `--skip-restart` / `--disable-nla` flags
- **`rdprrap-check`**: RDP loopback tester — spawns `mstsc /v:127.0.0.2:PORT`, `NlaGuard` RAII (SecurityLayer/UserAuthentication registry backup+restore, Drop-safe on panic), 44 disconnect-reason codes
- **`rdprrap-conf`**: Configuration GUI — native-windows-gui 1.0 + Frame-based layout, 1s timer diagnostics (Wrapper state, TermService SCM, termsrv version, RDP-Tcp listener, support level) + runtime settings (Enable RDP, Port, SingleSession, HideUsers, AllowCustom, AuthMode, Shadow), read-only mode when unprivileged
- Original rdpwrap feature-gap closure: C2 CheckInstall preflight + `--force`, H1 cohort service restart (EnumServicesStatusExW), H2 CheckTermsrvVersion, H3 install-dir ACL, H4 CheckTermsrvDependencies preflight, H4 fDenyTSConnections backup/restore
- 3 security audits completed: 0 CRITICAL, all HIGH/MEDIUM addressed (SDDL-protected backup key, reparse-point defense, NLA opt-in, fDenyTSConnections backup/restore, path validation, transactional rollback, DLL search-path hardening)
- CI updated: Windows x64/x86 × debug/release matrix, all 8 crates built + binary verification (DLL exports, PE architecture, size sanity, installer/check/conf `--help`)
- Memory system: `.priv-storage/memory/` portable persistent memory (iced-x86 API gotchas, NWG 1.0.13 API gotchas, team orchestration rules)
- **`rdprrap-installer plan` subcommand**: prints the full install contract — install directory, wrapper-DLL names, ServiceDll target, every HKLM registry key/value (name + DWORD/SZ data + type), firewall rule names + ports, uninstall behavior. Pure formatting over the `contract` module — no I/O, no registry access, no elevation required. Runs on Linux CI.
- **`contract` module**: single-source-of-truth for install-time constants (DLL names, registry keys, registry value names + data, firewall rule names + port). `paths`, `registry`, `firewall`, `install`, `uninstall` all re-export from `contract` so drift between code paths and the documented contract is impossible.
- **insta snapshot test**: pins the full `plan` manifest byte-for-byte — any change to DLL names, registry keys/values, firewall rules, or the ServiceDll value requires explicit `cargo insta accept`, catching unintended contract drift on Linux before it reaches a Windows host.
- **cargo-deny CI gate** (`deny.toml` + `deny` job): license allow-list (MIT/Apache/BSD/ISC/Unicode), banned-dep check, source-registry policy, `publish = false` at workspace level so the Cargo registry can never accept this crate.
- **offset-finder `--assert-all` mode** + Windows CI smoke test: runs the offset-finder against the hosted runner's own `C:\Windows\System32\termsrv.dll` on every release build — exercises the full runtime pattern-matching pipeline end-to-end against a real, current Windows build (hosted image is Server 2022, 10.0.20348.x).
- **windows-2025 matrix row**: adds one release x64 job pinned to the windows-2025 image so the offset-finder smoke test also hits a Server 2025 termsrv.dll alongside whatever `windows-latest` currently maps to. Server 2019 coverage was removed — the image was retired by GitHub Actions on 2025-06-30.

### Added (2026-03 initial release)
- Cargo workspace with 5 crates: `patcher`, `termwrap-dll`, `umwrap-dll`, `endpwrap-dll`, `offset-finder`
- `patcher` crate: PE header/section/import parsing, 4-byte aligned pattern matching, iced-x86 disassembly wrapper, WriteProcessMemory-based patching, 14 verified bytecode constants
- `termwrap-dll`: termsrv.dll proxy DLL with 7 patch types
  - DefPolicyPatch (direct CMP + indirect MOV+CMP, x64/x86, JZ/JNZ variants)
  - SingleUserPatch (memset→VerifyVersionInfoW and CMP patterns)
  - LocalOnlyPatch (TEST→JS/JNS→CMP→JZ to unconditional JMP)
  - NonRDPPatch (IsAllowNonRDPStack with inlined IsAppServerInstalled fallback)
  - PropertyDevicePatch (SHR+AND PnP device filtering with registry checks)
  - CSLQuery::Initialize SL policy variable patching (bRemoteConnAllowed, bFUSEnabled, bAppServerAllowed, bMultimonAllowed, bInitialized)
- `umwrap-dll`: umrdp.dll proxy DLL for USB/camera PnP redirection (legacy + modern modes, camera secondary patch)
- `endpwrap-dll`: rdpendp.dll proxy DLL for audio recording redirection (TSAudioCaptureAllowed)
- `offset-finder`: standalone CLI tool for termsrv.dll offset detection using pelite (x64 xref + x86 string scan)
- x64 function resolution via exception table xref search with unwind chain backtrace
- x86 function resolution via prologue scanning (8B FF 55 8B EC) with branch-following priority queue
- Thread suspension/resumption for safe in-memory patching
- DLL export forwarding (ServiceMain, SvchostPushServiceGlobals, GetTSAudioEndpointEnumeratorForSession, DllGetClassObject, DllCanUnloadNow)
- GitHub CI: Linux check + Windows x64/x86 full build with artifact upload
- 11 unit tests (pattern matching + disassembly)
- Bilingual documentation (English + Korean): README, SECURITY, CONTRIBUTING, CODE_OF_CONDUCT, CHANGELOG
- GitHub templates: PR template, bug report, feature request
- AI multi-tool configuration (.priv-storage/ v2.0)
- Encrypted backup toolkit (tmp-igbkp/)
